<template>
  <router-view></router-view>
</template>

<script>
export default {
}
</script>

<style scoped lang="scss">
header {
  color: $priceColor;
}
</style>
